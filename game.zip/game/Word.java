package game;

public class Word implements Formable<Word>, Comparable<Word> {
    @Override
    public boolean canForm(Word other) {
        // TODO: Fix me
        return false;
    }

    @Override
    public int compareTo(Word o) {
        // TODO: Fix me
        return 0;
    }
}
